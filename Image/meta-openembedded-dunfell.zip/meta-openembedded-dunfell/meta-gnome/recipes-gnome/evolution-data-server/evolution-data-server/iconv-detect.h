/* This is an auto-generated header, DO NOT EDIT! */

#define ICONV_ISO_D_FORMAT "iso-%d-%d"
#define ICONV_ISO_S_FORMAT "iso-%d-%s"
#define ICONV_10646 "iso-10646"
