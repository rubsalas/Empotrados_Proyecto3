/* This is an auto-generated header, DO NOT EDIT! */

#define ICONV_ISO_INT_FORMAT "iso-%u-%u"
#define ICONV_ISO_STR_FORMAT "iso-%u-%s"
#define ICONV_10646 "iso-10646"
