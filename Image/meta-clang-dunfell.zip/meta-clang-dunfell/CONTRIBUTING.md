
# Contributing

You are encouraged to follow Github Pull request workflow
to share changes and following commit message guidelines are recommended [OE patch guidelines](https://www.openembedded.org/wiki/Commit_Patch_Message_Guidelines)

Layer Maintainer: [Khem Raj](<mailto:raj.khem@gmail.com>)
